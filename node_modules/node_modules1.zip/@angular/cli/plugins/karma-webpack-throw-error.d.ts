export declare class KarmaWebpackThrowError {
    constructor();
    apply(compiler: any): void;
}
