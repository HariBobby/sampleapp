export declare const pluginArgs: symbol;
export declare const postcssArgs: symbol;
declare const _default: any;
export default _default;
