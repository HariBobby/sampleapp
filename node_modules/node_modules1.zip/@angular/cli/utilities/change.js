"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ast_tools_1 = require("../lib/ast-tools");
exports.NoopChange = ast_tools_1.NoopChange;
exports.MultiChange = ast_tools_1.MultiChange;
exports.InsertChange = ast_tools_1.InsertChange;
exports.RemoveChange = ast_tools_1.RemoveChange;
exports.ReplaceChange = ast_tools_1.ReplaceChange;
//# sourceMappingURL=/users/hansl/sources/angular-cli/utilities/change.js.map